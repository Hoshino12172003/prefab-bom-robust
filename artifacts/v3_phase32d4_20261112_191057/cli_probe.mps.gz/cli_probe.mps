NAME  TEST
OBJSENSE
 MAX
ROWS
 N obj
 L lim
COLUMNS
 M0 'MARKER' 'INTORG'
 x obj 1
 x lim 1
 M1 'MARKER' 'INTEND'
RHS
 rhs lim 5
BOUNDS
 PL bd x
ENDATA
