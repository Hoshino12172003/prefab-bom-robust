# Solution for model TEST
# Objective value = 5
x 5
