"""Limited independent V2.1 property checks; NOT complete V2.1 global certification.

Reuses original V2 toy LP for one-product staged material flow and tests
1) correct continuous-budget extreme point enumeration vs independent scipy.linprog
2) necessary BOM-T3 cover cut on feasible and infeasible toy scenarios
3) selected feasibility and deadline counterexamples.
"""
from __future__ import annotations
import itertools, json, math
from pathlib import Path
from typing import Iterable
import numpy as np
from scipy.optimize import linprog
import sys
sys.path.insert(0,str(Path(__file__).parent/'v2_bom_delivery'))
from v2_micro_flow_check import Toy, check


def extreme_vertices(n:int,gamma:float):
    if n < 0 or not (math.isfinite(gamma) and 0 <= gamma <= n):
        raise ValueError('bad n or gamma')
    if n == 0: return [tuple()]
    g=round(gamma) if abs(gamma-round(gamma))<1e-12 else gamma
    k=math.floor(g)
    result=set()
    for i in range(k+1):
        for ones in itertools.combinations(range(n),i):
            z=[0.0]*n
            for a in ones:z[a]=1.0
            result.add(tuple(z))
    frac=g-k
    if frac>1e-12 and k<n:
        for ones in itertools.combinations(range(n),k):
            for j in range(n):
                if j in ones: continue
                z=[0.0]*n
                for a in ones:z[a]=1.0
                z[j]=frac
                result.add(tuple(z))
    return sorted(result)


def check_budget_extrema():
    rng=np.random.default_rng(20261107)
    experiments=0
    for n in range(1,6):
        for gamma in [0.0,0.5,1.,1.5,2.,2.5,3.]:
            if gamma>n: continue
            vv=np.asarray(extreme_vertices(n,gamma))
            assert all(0 <= t <= 1+1e-10 for v in vv for t in v)
            assert all(sum(v) <= gamma+1e-10 for v in vv)
            for _ in range(6):
                c=rng.normal(size=n)
                lp=linprog(-c,A_ub=np.ones((1,n)),b_ub=[gamma],bounds=[(0,1)]*n,method='highs')
                assert lp.success,lp.message
                mx=max(float(c@v) for v in vv)
                assert abs(mx+lp.fun)<1e-8,(n,gamma,c,mx,lp.fun)
                experiments+=1
    return experiments


def check_cover():
    cases=[
        Toy('normal_internal_partial_assembly',xi=0),
        Toy('half_disruption_backup_fractional',xi=0.5),
        Toy('full_T3_disruption_with_backup',xi=1),
        Toy('full_T3_disruption_without_backup',xi=1,backup_reserved=0),
        Toy('backup_arrives_too_late',xi=1,backup_lead=2),
        Toy('external_WIP_returns_in_time',T=3,deadline=2,xi=1,backup_reserved=0,main_A0=0,main_B0=1,ext_A0=1,internal_p1=(0,0,0),ext_p1=(1,0,0),internal_p2=(0,1,0),wip_lead=1),
        Toy('external_partner_down',T=3,deadline=2,xi=1,backup_reserved=0,main_A0=0,main_B0=1,ext_A0=1,internal_p1=(0,0,0),ext_p1=(1,0,0),internal_p2=(0,1,0),theta=1,wip_lead=1),
        Toy('external_WIP_returns_too_late',T=3,deadline=2,xi=1,backup_reserved=0,main_A0=0,main_B0=1,ext_A0=1,internal_p1=(0,0,0),ext_p1=(1,0,0),internal_p2=(0,1,0),wip_lead=2)
    ]
    out=[]
    for c in cases:
        lp=check(c)
        short=lp['minimum_service_shortfall']
        # Each on-time completed product consumes 1 unit stage-2 component B,
        # production uses at least 1 unit of common upstream input k.
        # U_k sums all normal T3-period nominal capacities + total reserved backup,
        # ignoring lead times, so this condition is NECESSARY, not sufficient.
        req=1.
        bound=c.main_B0 + c.T*(1-c.xi) + c.backup_reserved
        if short<1e-8:
            assert req <= bound+1e-8,(c.name,req,bound)
        out.append({'case':c.name,'phase_i_shortfall':short,
                    'necessary_cut_requirement':req,
                    'necessary_cut_supply_upper':round(bound,8),
                    'cut_violated':bool(req>bound+1e-8)})
    assert next(z for z in out if z['case']=='full_T3_disruption_without_backup')['cut_violated']
    assert not next(z for z in out if z['case']=='backup_arrives_too_late')['cut_violated']
    return out


def main():
    lp_checks=check_budget_extrema()
    cuts=check_cover()
    summary={'status':'LIMITED_STRUCTURAL_CHECKS_ONLY',
             'independent_linear_objective_vertex_checks':lp_checks,
             'toy_phase_i_and_necessary_cut_checks':len(cuts),
             'note':'No full V2.1 model, Gurobi, or exact multi-scenario C&CG was run.',
             'cases':cuts}
    p=Path(__file__).parent/'第二篇论文_V2.1_局部检查证据.json'
    p.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{lp_checks} risk-polytope LP comparisons + {len(cuts)} toy cut/recourse checks passed')
    for o in cuts:
        print(o['case'], 'shortfall',o['phase_i_shortfall'],'cover_cut_violated',o['cut_violated'])
if __name__=='__main__':main()
