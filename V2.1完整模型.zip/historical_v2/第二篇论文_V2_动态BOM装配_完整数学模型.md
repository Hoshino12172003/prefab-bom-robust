# 第二篇论文 V2：连续多层级供给扰动下，考虑分期物料流、在制品和外协装配的鲁棒交付保障

> **状态：研究模型 V2-DRAFT / 待独立数值验收。** V1 已按用户提供的 Codex 报告完成小规模 `PASS_V1_EXACT`；**不意味着 V2 已通过该认证**。本文档以 V1 决策时序、T2/T3 共享上游资源、连续分层风险预算、名义成本与鲁棒交付要求为基线，进一步构造 **两阶段、第二阶段多时期** 的连续追索模型。公式均采用 Typora/Markdown 的 `$...$` 与 `$$...$$`。每个成本仅计入一次，所有物料在使用前必须到达实际工位。

## 3.1 研究问题与研究边界

研究一个既有模块化装配供应网络，最终配置集合 $M$ 分属 $H=\{HV,MV,LV\}$ 三类产品族。T3 提供关键上游资源，T2 将资源转化为合格组件，组件流向内部装配厂或经过认证的外协工位。每个最终产品配置包含 **两道汇总工序**：工序1（可进行部分预装配），工序2（最终集成、检验与成品形成）。工序1可在厂内或合格外协节点进行；外协完成的在制品（WIP）经过确定的运输提前期返回总装厂，工序2只能在总装厂进行。完成工序2不自动等于交付，必须按成品运输提前期在订单截止时点前送达。

### 3.1.1 信息顺序与两阶段定义

1. **第一阶段（$t=0$，风险未揭示）**：决定各库存地点的预置组件量 $x_{j\ell}$、备用上游协议 $y_k$、整个窗口的备用可用总供货量 $r_k$；这些变量对全部未来情景保持相同。
2. **风险揭示（运营期开始前）**：T3、T2 与外协加工节点在交付窗口内的能力折减程度 $\omega=(\xi,\eta,\theta)$ 一次揭示并保持不变（各期名义产能轮廓允许已知地变化）。
3. **第二阶段（$t=1,\ldots,T$）**：已观察 $\omega$ 后，企业一次性联合优化各期 T3 发货、T2 生产、采购运输、各地点组件库存、工序1、外协 WIP 运输、工序2、成品库存与交付。这是**两阶段鲁棒优化中的多期追索**，**不是**逐期揭示新风险的多阶段鲁棒规划。
4. **名义运营成本**：另行求解 $\omega=0$ 的正常全额履约方案 $v^0$，作为主目标中的名义成本参照。第二阶段风险情景下不必执行该名义计划。

### 3.1.2 时段事件顺序

离散时期 $t$ 的顺序约定如下：① 期初到货和外协 WIP 运输到达；② T2 使用已到达的 T3 输入生产，并在期末发运成品组件；③ 装配工位使用**本期已到达且可用**的组件进行工序1、随后工序2（厂内工序1产出可以在同一期后续工序2使用）；④ 厂内组件调拨、外协 WIP 发出与成品发运，按规定提前期到达；⑤ 记录期末库存。**跨节点实物运输提前期至少为一个时期**，不允许未到达的物料提前消耗；最终客户交付提前期允许为0（厂内完成后当期交付）。

若研究日级且不能接受厂内两道工序同日衔接，可以改用严格跨期先后约束（见审计文档），但不能两种口径混用。

## 3.2 集合、索引与既有供应关系

| 记号 | 含义 |
|---|---|
| $H, M_h, M=\bigcup_hM_h$ | 产品族及其最终产品配置（$h,m$） |
| $J$ | 关键组件（$j$） |
| $S$ | 合格 T2 零部件生产商（$s$） |
| $V$ | T3 上游供应商（$v$） |
| $K$ | 同质上游资源池（$k$）；$v(k)\in V$ 标识归属 |
| $O$ | 外协工序1加工企业/工位（$o$），与 T2 的零部件生产角色不同 |
| $L=\{a\}\cup O$ | 组件库存地点；$a$ 是内部总装厂，$o$ 是外协工位 |
| $\mathcal T=\{1,\ldots,T\}$ | 交付窗口内离散时期（$t$） |
| $E\subseteq S\times J$ | T2—组件生产资格 |
| $N\subseteq K\times S$ | T3 正常输入合格路径 |
| $N^B\subseteq N$ | 同种输入的独立备用来源合格路径 |
| $A^{SL}\subseteq S\times J\times L$ | T2 组件可发往的合法目的地及对应线路 |
| $A^{LL}\subseteq J\times L\times L$ | 组件在库存地点之间的合法转运路径；不含自环 |
| $E^O\subseteq M\times O$ | 外协工位 $o$ 可完成配置 $m$ 的工序1的资质 |
| $\Omega$ | T2/T3/外协节点连续预算型风险集合 |

只对合格关系创建相应的流量与加工变量。每个上游池 $k$ 代表一种有物理单位的投入，不能将不同资源类型的数量当成可互换产能。外协工位只加工工序1，不把外协商同时虚构为能提供所有 T2 组件的供应商。

## 3.3 输入参数及单位

**产品与分工序 BOM**：$D_m\ge0$ 为已确认产品订单数量；$d_m\in\mathcal T$ 为最终客户截止期；$A^1_{jm},A^2_{jm}\ge0$ 分别表示每单位产品在工序1和2消耗的组件 $j$ 数量，必须满足

$$A^1_{jm}+A^2_{jm}=A_{jm},\quad \forall j,m.\tag{1}$$

一个产品允许在缺少工序2物料时先完成工序1，但**不得**在缺少工序1必需物料时完成工序1。$\tau^1_m,\tau^2_m$ 为厂内两道工序单位能力消耗，$\tau^O_{mo}$ 为外协工序1在 $o$ 的能力消耗。$P^1_{a,t},P^2_{a,t}$ 为厂内两工序各期可用能力；$\bar P^O_{o,t}$ 为外协各期名义工序1能力。

**供应与折损**：$a_{sj}\ge0$ 为每单位组件消耗的 T2 本级能力；$b_{ksj}\ge0$ 为每单位组件必需的上游输入；$\bar K_{s,t}$、$\bar C_{k,t}$ 为 T2 与 T3 各期名义可用能力；$\epsilon_s,\delta_k,\chi_o\in[0,1]$ 为 T2、T3 与外协各自最大能力损失比例。若 $b_{ksj}>0$，要求 $(s,j)\in E,(k,s)\in N$。

**提前期**：$L^{3N}_{ks},L^{3B}_{ks}\ge1$ 分别为 T3 正常/备用资源至 T2 的提前期；$L^2_{sj\ell}\ge1$ 为 T2 组件至库存地点的提前期；$L^{LL}_{j\ell\ell'}\ge1$ 为地点间组件调拨提前期；$L^W_{mo}\ge1$ 为外协工序1 WIP 返回总装厂的提前期；$L^F_m\ge0$ 为总装成品发运至客户的提前期。所有提前期为在所选时间尺度下的整数。若真实交期不确定，应单独定义交期风险；V2 不擅自将其当作已观测随机数据。

**初始存量与已在途物料**：$R^0_{ks}\ge0$ 为期初在 T2 存放的上游输入；$S^0_{sj}\ge0$ 为期初 T2 已产组件；$I^0_{j\ell}\ge0$ 为各装配地点的期初组件；$W^0_{ma},W^0_{mo}\ge0$ 为厂内/外协期初工序1 WIP；$F^0_m\ge0$ 为厂内期初成品。$P^3_{ks,t},P^2_{j\ell,t},P^W_{m,t},P^F_{m,t}\ge0$ 分别为**风险揭示前已不可撤销、且在期初按原定计划到达**的上游输入、组件、回厂 WIP 与终端客户交付。上述各项是预定存量/在途项，并非风险实现后新生成的供应能力。如果这些在途物料实际上可能中断，也必须设置相应风险而不能沿用保证到货假设。

**库存与合同**：$\bar X_{j\ell}$、$\bar R_k$ 为新增组件库存及备用总合同量上界；$\bar G_{k,t}$ 为备用来源的每期发运能力；$\operatorname{Cap}^I_\ell$、$\operatorname{Cap}^W_\ell$ 为可选的组件/WIP 库容。容量不设或取足够大时，仍需要实际的非负物料守恒。

**成本**：$c^I_{j\ell}$ 为事前新增库存采购/定位成本；$f_k,c^R_k$ 为独立备用合同固定费和预留单位供货量费用；$c^Q_{sj}$ 为 T2 单位组件的普通采购成本（**已包含正常 T3 输入的常规成本**）；$c^A_{ks}$ 为备用上游输入**额外**调用费用；$c^2_{sj\ell},c^{LL}_{j\ell\ell'},c^W_{mo},c^F_m$ 为运输成本；$c^{1a}_m,c^{1o}_{mo},c^{2a}_m$ 为厂内工序1、外协工序1和厂内工序2单位加工费；$h^I_{j\ell},h^R_{ks},h^S_{sj},h^W_{m\ell},h^F_m$ 为对应期末库存/在制品持有费。

$B_{\mathrm{pre}}$ 为事前保障资金上限；$E_{\mathrm{op}}$ 为**每个运营情景整个窗口内**可支出的运营资金上限；$\alpha_h\in[0,1]$ 是各产品族的**数量型**最低及时交付比例。不同产品数量不具可比性时，应按订单价值或合同权重另定义指标，不能直接将“设备台数”解释为统一经济价值。

### 3.3.1 前期成本与第一阶段变量

第一阶段 $x_{j\ell}\ge0$ 为**风险前就已经可用**的组件预置库存；$y_k\in\{0,1\}$ 为独立备用协议；$r_k\ge0$ 为**整个交付窗口合约锁定的备用上游输入总供货量**（不是每期可重复使用的生产能力）。其约束为

$$0\le x_{j\ell}\le\bar X_{j\ell},\qquad \forall j,\ell,\tag{2}$$

$$0\le r_k\le\bar R_k y_k,\qquad y_k\in\{0,1\},\quad\forall k.\tag{3}$$

$$C^{\mathrm{pre}}(x,y,r)=\sum_{j,\ell}c^I_{j\ell}x_{j\ell}+\sum_k(f_ky_k+c^R_kr_k),\tag{4}$$

$$C^{\mathrm{pre}}(x,y,r)\le B_{\mathrm{pre}}.\tag{5}$$

新增库存可分散于总装厂和外协工位（仅限可合法入库的合格组件）；要复现 V1，可额外规定 $x_{jo}=0$ 并令 $x_{ja}=x_j$。所有情景共享同一个 $(x,y,r)$。

## 3.4 连续分层供给风险

$$\boxed{\Omega=\left\{(\xi,\eta,\theta):\begin{array}{ll}
0\le\xi_v\le1,\ \sum_v\xi_v\le\Gamma_3,& v\in V,\\
0\le\eta_s\le1,\ \sum_s\eta_s\le\Gamma_2,& s\in S,\\
0\le\theta_o\le1,\ \sum_o\theta_o\le\Gamma_O,& o\in O
\end{array}\right\}.}\tag{6}$$

三个风险预算分别限制上游供应、零部件生产和外协工序的归一化扰动；它们不是发生概率，也不是财务预算。一次情景的扰动程度在所有时期保持不变，但每期名义可用能力可随事先已知排班变化：

$$K_{s,t}(\eta)=\bar K_{s,t}(1-\epsilon_s\eta_s),\quad C_{k,t}(\xi)=\bar C_{k,t}(1-\delta_k\xi_{v(k)}),\quad P^O_{o,t}(\theta)=\bar P^O_{o,t}(1-\chi_o\theta_o).\tag{7}$$

如果一个外协工厂同时是 T2 节点、且物理上共享同一生产资源，不应再把 $\eta_s$ 与 $\theta_o$ 当作互不关联的两次独立产能折减；数据构造必须去重或以同一个风险因子和共享资源上限表述。

## 3.5 第二阶段：动态输入、组件与装配物流

以下对给定 $\omega\in\Omega$ 描述追索变量和约束，省略其 $\omega$ 下标。统一定义：**凡是时间索引 $\tau\notin\mathcal T$ 的情景可调发运量均取0**；提前期内已经在途的物料只能通过独立参数 $P^3,P^2,P^W,P^F$ 计入。所有未授权线路的流量变量不存在。超过截止期而对当前订单没有交付贡献的发运，应禁止或由显式残值模型处理；V2 基础版禁止相应最终成品晚到发运。

### 3.5.1 T3 正常与备用上游输入发运

$t_{ks,t}\ge0$：正常 T3 资源池 $k$ 于期 $t$ 发给 T2 $s$ 的量，$(k,s)\in N$；$g_{ks,t}\ge0$：独立备用来源在合格线路 $(k,s)\in N^B$ 的期 $t$ 发货量。

$$\sum_{s:(k,s)\in N}t_{ks,t}\le \bar C_{k,t}(1-\delta_k\xi_{v(k)}),\qquad\forall k,t.\tag{8}$$

$$\sum_{t\in\mathcal T}\sum_{s:(k,s)\in N^B}g_{ks,t}\le r_k,\qquad \forall k.\tag{9}$$

$$\sum_{s:(k,s)\in N^B}g_{ks,t}\le\bar G_{k,t}y_k,\qquad\forall k,t.\tag{10}$$

沿用 V1 约定，**备用仅用于替代该池本期主供给能力损失**，再加入

$$\sum_{s:(k,s)\in N^B}g_{ks,t}\le\bar C_{k,t}\delta_k\xi_{v(k)},\qquad\forall k,t.\tag{11}$$

这是可变更的合同机制假设，不是所有双源采购合同的通用事实。备用发运虽然必须补偿受损池输入，但本身来自**独立、合格**的真实供货来源；按路线提前期到达 T2，不能即时转换为最终产品。

### 3.5.2 T2 上游输入库存与组件生产

设 $R_{ks,t}\ge0$ 为 T2 $s$ 期末持有的资源池 $k$ 输入库存；$q_{sj,t}\ge0$ 为 T2 于期 $t$ 生产组件 $j$ 的数量，$(s,j)\in E$。定义 $\tilde g_{ks,\tau}=g_{ks,\tau}$（合格备用路径）或0（不合格路径）。

$$\boxed{R_{ks,t}=R_{ks,t-1}+P^3_{ks,t}+t_{ks,t-L^{3N}_{ks}}+\tilde g_{ks,t-L^{3B}_{ks}}-\sum_{j:(s,j)\in E}b_{ksj}q_{sj,t},}\quad \forall(k,s)\in N,t.\tag{12}$$

初值 $R_{ks,0}=R^0_{ks}$，且所有 $R_{ks,t}\ge0$。当 $t-L<1$ 时，对应情景决策发货量为零，不能将负期索引理解为额外自由库存。

$$\sum_{j:(s,j)\in E}a_{sj}q_{sj,t}\le \bar K_{s,t}(1-\epsilon_s\eta_s),\qquad\forall s,t.\tag{13}$$

由于所有需要的资源池 $k$ 均分别受式（12）约束，生产一种组件需要的多种上游输入必须同时充足，不能以其他材料富余替代缺失输入。

### 3.5.3 T2 成品组件库存及其运输

$S_{sj,t}\ge0$ 为 T2 $s$ 期末已产组件 $j$ 库存；$z_{sj\ell,t}\ge0$ 为期 $t$ 从 T2 $s$ 向合格目的地 $\ell$ 发运的组件 $j$，仅在 $(s,j,\ell)\in A^{SL}$ 创建。

$$\boxed{S_{sj,t}=S_{sj,t-1}+q_{sj,t}-\sum_{\ell:(s,j,\ell)\in A^{SL}}z_{sj\ell,t},}\qquad\forall(s,j)\in E,t,\tag{14}$$

$$S_{sj,0}=S^0_{sj},\qquad S_{sj,t}\ge0.\tag{15}$$

组件到达地点 $\ell$ 的数量（含**事前已在途**保证到货）定义为

$$\operatorname{Arr}^{2}_{j\ell,t}=P^2_{j\ell,t}+\sum_{s:(s,j,\ell)\in A^{SL}}z_{sj\ell,t-L^2_{sj\ell}}.\tag{16}$$

必要时可增加运输线路容量、T2 组件仓容或货运批次限制；基础 V2 保持连续流量，未引入整车运输批次整数决策。

### 3.5.4 装配地点之间的组件调拨与分期库存

$m_{j\ell\ell',t}\ge0$ 为组件 $j$ 于期 $t$ 从库存地点 $\ell$ 发往地点 $\ell'$ 的转移量，仅在合法路径 $(j,\ell,\ell')\in A^{LL}$ 上定义。$I_{j\ell,t}\ge0$ 为地点 $\ell$ 的期末组件库存。

设 $a_{m\ell,t}\ge0$ 表示在地点 $\ell$ 完成的产品 $m$ 的工序1数量：$\ell=a$ 为内部装配，$\ell=o$ 仅当 $(m,o)\in E^O$ 方可取正值。设 $b_{m,t}\ge0$ 为**总装厂工序2**完成量。

$$\boxed{\begin{aligned}
I_{j\ell,t}={}&I_{j\ell,t-1}+\operatorname{Arr}^{2}_{j\ell,t}
+\sum_{\ell'\ne\ell:(j,\ell',\ell)\in A^{LL}}m_{j\ell'\ell,t-L^{LL}_{j\ell'\ell}}\\
&-\sum_{\ell'\ne\ell:(j,\ell,\ell')\in A^{LL}}m_{j\ell\ell',t}
-\sum_{m\in M}A^1_{jm}a_{m\ell,t}
-\mathbf1_{\{\ell=a\}}\sum_{m\in M}A^2_{jm}b_{m,t}.
\end{aligned}}\tag{17}$$

$$I_{j\ell,0}=I^0_{j\ell}+x_{j\ell},\qquad I_{j\ell,t}\ge0,\qquad\forall j,\ell,t.\tag{18}$$

式（17）明确区分“生产已发生”与“物料已到达”：某组件必须真正到达本工位且尚未被其他工序使用，才能用于当前工序。对全部地点与供应商的存量流量求和，会使合法转运只改变位置与到货时间，不凭空创造组件。

若设置仓容，应在 $t=0$ 和各期分别满足 $\sum_j\upsilon_jI_{j\ell,t}\le\operatorname{Cap}^I_\ell$；且初始保证在途到货可能导致仓容超限，须有明确的合法转运/处置机制，详见审计。

### 3.5.5 两道装配工序及内外协产能

内部工序1和2分别受各期能力限制：

$$\sum_{m\in M}\tau^1_ma_{ma,t}\le P^1_{a,t},\qquad \sum_{m\in M}\tau^2_mb_{m,t}\le P^2_{a,t},\qquad\forall t.\tag{19}$$

外协工序1的资质、能力和供给状态为：

$$a_{mo,t}=0\quad ((m,o)\notin E^O),\qquad\sum_{m:(m,o)\in E^O}\tau^O_{mo}a_{mo,t}\le\bar P^O_{o,t}(1-\chi_o\theta_o),\quad\forall o,t.\tag{20}$$

外协企业是**既有合格加工伙伴**，本版不让风险发生后临时认证一个新外协商；其按期实际加工费用进入运营成本。若需要事前锁定外协资格或产能，必须另加固定签约/预留变量与成本，作为新的模型版本验收。

### 3.5.6 外协 WIP、返厂在制品与工序顺序

设 $W^o_{mo,t}\ge0$ 为外协工位 $o$ 期末已完成工序1但尚未送出的 WIP；$h_{mo,t}\ge0$ 为当期发往总装厂的 WIP（仅 $m,o$ 合格）；$W^a_{m,t}\ge0$ 为总装厂期末可进入工序2的 WIP。

$$\boxed{W^o_{mo,t}=W^o_{mo,t-1}+a_{mo,t}-h_{mo,t},}\quad\forall (m,o)\in E^O,t,\tag{21}$$

$$\boxed{W^a_{m,t}=W^a_{m,t-1}+a_{ma,t}+P^W_{m,t}+\sum_{o:(m,o)\in E^O}h_{mo,t-L^W_{mo}}-b_{m,t},}\quad\forall m,t.\tag{22}$$

$$W^a_{m,0}=W^0_{ma},\qquad W^o_{mo,0}=W^0_{mo};\quad W^a_{m,t},W^o_{mo,t}\ge0.\tag{23}$$

式（22）是工序先后关系：工序2不能超过**厂内已可用 WIP + 当期内部工序1完成量 + 本期真实到达的外协 WIP**。不能将尚在外协工厂或运输途中的在制品直接计为可交付成品。外协运输提前期严格为正。

厂内同一期允许先完成工序1再完成工序2；若工序最短加工时间跨期，应使用相应滞后约束及新状态流，当前 V2 不能声称刻画了小时级先后排程。

### 3.5.7 成品库存、最终客户到货与交付期限

$F_{m,t}\ge0$ 为厂内期末可发成品库存；$e_{m,t}\ge0$ 为期 $t$ 发往客户的成品；$\ell_{m,t}\ge0$ 为期 $t$ **实际到达客户**的完整产品数量（与配送提前期区别开）。

$$F_{m,t}=F_{m,t-1}+b_{m,t}-e_{m,t},\quad F_{m,0}=F^0_m,\quad F_{m,t}\ge0.\tag{24}$$

$$\boxed{\ell_{m,t}=P^F_{m,t}+e_{m,t-L^F_m},}\qquad\forall m,t.\tag{25}$$

$$e_{m,t}=0\quad\text{若 }t+L^F_m>d_m,\qquad\sum_{t=1}^{d_m}\ell_{m,t}+u_m=D_m,\quad u_m\ge0,\quad\forall m.\tag{26}$$

$P^F_{m,t}$ 代表窗口前已发运而本期到达的合格成品，必须进入需求平衡和成本口径审计，不能把期初成品或发运途中的货物重复计数。式（26）不计迟于期限到达的产品为及时交付；若研究延期交付及罚款，应新增逾期订单状态和时间成本，属于扩展。

### 3.5.8 分类鲁棒交付保障

$$\boxed{\sum_{m\in M_h}\sum_{t=1}^{d_m}\ell_{m,t}\ge\alpha_hD_h,\qquad D_h=\sum_{m\in M_h}D_m,\quad\forall h\in H.}\tag{27}$$

全部 $h$ 的保障要求由**相同供给风险 $\omega$ 下的同一套 T3/T2/内部/外协/物料/WIP 流**联合满足。不能分别对每个产品族求单独最优计划再拼起来。若某些关键产品具有单独的合同下限，可在后续版本增加配置级要求 $\sum_{t\le d_m}\ell_{m,t}\ge\alpha_mD_m$，但不擅自将其视为所有真实合同的事实。

### 3.5.9 完整运营成本、资金与库存容量

记全部上述多期运营变量构成向量 $v(\omega)$。本版窗口运营成本为

$$\begin{aligned}
C^{\mathrm{op}}(v;\omega)=\sum_{t\in\mathcal T}\Big[&\sum_{(s,j)\in E}c^Q_{sj}q_{sj,t}
+\sum_{(k,s)\in N^B}c^A_{ks}g_{ks,t}
+\sum_{(s,j,\ell)\in A^{SL}}c^2_{sj\ell}z_{sj\ell,t}\\
&+\sum_{(j,\ell,\ell')\in A^{LL}}c^{LL}_{j\ell\ell'}m_{j\ell\ell',t}
+\sum_{(m,o)\in E^O}c^W_{mo}h_{mo,t}+\sum_m c^F_me_{m,t}\\
&+\sum_m(c^{1a}_ma_{ma,t}+c^{2a}_mb_{m,t})+\sum_{(m,o)\in E^O}c^{1o}_{mo}a_{mo,t}\\
&+\sum_{j,\ell}h^I_{j\ell}I_{j\ell,t}+\sum_{(k,s)\in N}h^R_{ks}R_{ks,t}
+\sum_{(s,j)\in E}h^S_{sj}S_{sj,t}\\
&+\sum_m h^W_{ma}W^a_{m,t}+\sum_{(m,o)\in E^O}h^W_{mo}W^o_{mo,t}+\sum_m h^F_mF_{m,t}\Big].
\end{aligned}\tag{28}$$

式（28）的成本按“购置/加工/增量运输/持有”分别计价：$c^Q$ 包含正常 T3 原料的内部采购成本，所以 $t_{ks,t}$ 不再另收一次正常采购费；预置组件的历史/事前购入费用不在风险情景的 $q$ 中再计。外协加工费只对实际在外协完成的工序1收取；其 WIP 运输另付费。若实际可观察采购报价已含某段运输费，应对应将该运输项设零，避免重复计价。

$$C^{\mathrm{op}}(v(\omega);\omega)\le E_{\mathrm{op}},\qquad \forall\omega\in\Omega.\tag{29}$$

可选仓容与 WIP 容量：

$$\sum_j\upsilon_j I_{j\ell,t}\le\operatorname{Cap}^I_\ell,\qquad \sum_m W^a_{m,t}\le\operatorname{Cap}^W_a,\qquad \sum_m W^o_{mo,t}\le\operatorname{Cap}^W_o.\tag{30}$$

这些约束必须先完成仓容/强制到货可行性审计后才能纳入需要完全 Phase-I 补救的计算代码。V2 基础数学模型可保留容量，但不能未经检查就断言所有事前方案/情景的松弛型 Phase-I 一定可行。

## 3.6 名义运营方案与正式鲁棒模型

记 $Y^{\mathrm{phys}}(z,\omega)$ 为给定事前资源方案 $z=(x,y,r)$、情景 $\omega$ 下由式（8）至（26）、（28）至（30）定义的全部物理合法运营计划（含式（26）的产品订单平衡及非负性，但**暂不包括式（27）的服务下限**）。记

$$Y^{\mathrm{svc}}(z,\omega)=\{v\in Y^{\mathrm{phys}}(z,\omega):\text{式（27）成立}\}.\tag{31}$$

名义运营成本是风险全零、备用不可启用、**每个产品按订单期限全部交付**的最小运营成本：

$$C^{\mathrm{nom}}(z)=\min\{C^{\mathrm{op}}(v^0;0):v^0\in Y^{\mathrm{phys}}(z,0),\ u_m^0=0\ \forall m\}.\tag{32}$$

正式的 V2 两阶段鲁棒模型写成

$$\boxed{\begin{aligned}
\min_{z\in X,\,v^0}\quad&C^{\mathrm{pre}}(z)+C^{\mathrm{op}}(v^0;0)\\
\mathrm{s.t.}\quad&v^0\in Y^{\mathrm{phys}}(z,0),\quad u_m^0=0,\ \forall m,\\
&\forall\omega\in\Omega,\ \exists\,v(\omega)\in Y^{\mathrm{svc}}(z,\omega),\\
&C^{\mathrm{pre}}(z)\le B_{\mathrm{pre}}.
\end{aligned}}\tag{V2-P}$$

此处 $X$ 包括式（2）和（3）及可选的事前场地库存限制。模型**并未**以最坏情景采购成本为主目标；风险后经济性通过式（29）约束并在正式实验中单独评价。需要避免“正常费用最低、风险费用极高但仍低于 $E_{\mathrm{op}}$”的管理偏差，应报告成本并考虑后续风险成本扩展。

若 $Y^{\mathrm{svc}}$ 在某些情景为空，当前 $z$ 不符合鲁棒保障。若名义全部订单不能在截止期内完成，则基础模型本身无解；不能通过把 WIP 当成成品掩盖它。

## 3.7 风险服务可行性、极点与 C&CG 基线

对任意事前 $z$ 和风险 $\omega$，对产品族引入松弛 $\sigma_h\ge0$，将式（27）替换为

$$\sum_{m\in M_h}\sum_{t\le d_m}\ell_{m,t}+\sigma_h\ge\alpha_hD_h.\tag{33}$$

定义**Phase-I** 最低服务不足量

$$\Phi(z,\omega)=\min\left\{\sum_{h\in H}\sigma_h:\ v\in Y^{\mathrm{phys}}(z,\omega),\ \sigma\ge0,\ \text{式（33）}\right\},\tag{34}$$

$$\Psi(z)=\max_{\omega\in\Omega}\Phi(z,\omega).\tag{35}$$

**精确等价的前提**：对给定 $z$ 和每个 $\omega$，基础物理运营集合 $Y^{\mathrm{phys}}(z,\omega)$ 非空且成本有界。此时

$$z\text{ 满足全部分类鲁棒交付要求}\quad\Longleftrightarrow\quad\Psi(z)=0.\tag{36}$$

如果某个情景连基础物理可行方案都不存在（例如事先锁定的强制在途量压垮库容），只给服务松弛 **不能**修复该情景；必须运行真正的可行性证书/Farkas 处理或在数据阶段阻断这种实例。不能把不可求解的 Phase-I 误记为服务缺口0。

**凸性与极点性质**：固定 $z$ 时，如果第二阶段所有运营/装配数量连续、提前期及供应资格为确定参数、风险仅仿射进入约束右端、可行域非空且目标有界，那么 $\Phi(z,\omega)$ 是关于 $\omega$ 的凸分段线性函数。故

$$\boxed{\Psi(z)=\max_{\omega\in\operatorname{ext}(\Omega)}\Phi(z,\omega).}\tag{37}$$

其中 $\operatorname{ext}(\Omega)$ 为分层连续预算多面体的极点。**风险集合可含非整数 $\Gamma$，不能把连续风险错误改成只取0、1。** 由于式（11）的备用启用上限可能随中断程度上升，最坏服务不足量**不应未经证明就假定关于所有风险变量逐点单调**；极点认证应保留不饱和极点，或在有额外证明时才安全缩减。

在可枚举的小实例中，通过全部极点展开的确定性等价 MILP 与 C&CG 交叉核验。在中大规模时，极点数量可能组合爆炸，要求具有严格最坏情景界的精确分离器；仅使用对偶影子价格排序、启发式搜索或未经证明紧致的连续双线性松弛不构成全局最优性认证。

**算法候选**：按时间窗与提前期推导的有效物料可达性/齐套容量割、BOM—T3—外协 WIP 结构引导的风险候选生成、精确极点分离与场景管理。这些都**仅为候选**，需先证明割有效且有独立验证，再以性能消融证明创新。

## 3.8 与 V1 的关系及需要明确的新假设

V2 继承：既有供应网络、不建设仓库、事前组件/备用投资、连续预算型 T3/T2 产能风险、名义成本最小与分类鲁棒服务。V2 新增：可分工序 BOM、时间、物料到达与库存守恒、外协工序状态、WIP 移动和各产品的实际交付截止期。**V1 的静态总量变量不是简单加一个时间下标就能精确得到 V2。** 仅在全部相关提前期可忽略、各期累计容量与总容量对应、工序与 WIP 不产生额外瓶颈、外协不启用且物流成本口径一致等专门条件下，才可能将 V2 的汇总约束约化到 V1；必须逐式检验，不应在论文中无条件声称 V1 是 V2 的严格特殊例。

关键业务假设包括：工序1、工序2仅是**聚合的两道装配工序**（不是实际企业认证工艺）；交期以固定整数时段表达；初始在途物料是可靠到货承诺；V2 风险在期初一次性揭示并维持同一归一化折减；外协方只承担已认证工序1；各类库存以及产量采用连续汇总数量，不等于单台设备允许分数交付。

## 3.9 结构性验证用手工示例（非求解器认证）

取 $T=3$，一种最终产品 $m$，订单 $D_m=1$、截止 $d_m=3$。工序1消耗组件 A 一单位，工序2消耗组件 B 一单位；厂内期初 A=1、B=0，全部工序能力每期至少1。一个 T3 输入池 $k$ 与一个 T2 供应商 $s$，每单位 B 需要1单位 T3 输入；T3→T2 运输时间1期，T2→装配厂运输时间1期；最终成品交付时间0。构造以下计划：

- 第1期：使用现有 A 完成工序1，形成一单位 WIP；T3 发出一单位生产 B 的正常资源。
- 第2期：T3 输入到达 T2，T2 生产一单位 B 并在期末发往装配厂；WIP 保留。
- 第3期：B 到达厂内，工序2消耗一单位 B 与一单位 WIP，完成并当期交付一单位完整产品。

上述计划满足静态 BOM 总量且**有意义地利用了提前装配**；如果错误地要求“所有组件先齐套才允许启动工序1”，第1期的 WIP 无法形成。若 $\xi_k=1$ 导致第1期正常 T3 供给为零，那么在第1期有充足且合格的独立备用投入 $g_{ks,1}=1$、其在第2期到达时，仍可实现第3期交付；若备用提前期大于1期，则未必可行。这个例子只给出一个**存在性证人计划**，未构成 V2 在全部风险极点上的精确验收。

## 3.10 可检验性质与下一阶段验收要求

1. 对固定风险与事前方案，逐一审计所有 $R,S,I,W,F$ 存量方程的非负性和流入流出，不得出现跨节点重复物料使用。
2. 验证 $q_{sj,t}$ 无法在相应上游输入到达之前生产、组件不能在运输到达前用于工序1/2、外协 WIP 不能未回厂就被工序2消耗。
3. 验证内外协工序1能力与厂内工序2能力各自约束；同一外协能力不被多个产品重复计入。
4. 验证风险影响既有供应节点和外协能力，但不存在隐藏的免费加班/临时采购；备用合同总量和每期能力都不能超限。
5. 验证阶段1提前加工虽然可能形成 WIP，但只有按期完成工序2并按期送达才计入最终交付。
6. 分别使用正常与受扰情景、零库存/仅库存/仅备用、外协开/关、提前期1/2、截止期早/晚构造微型反例，比较手算、独立 LP/MILP 和 C&CG。
7. 设定所有库存、供给单位、装配工时、路径成本和提前期的统一数据字典；非公开的工序 BOM、外协资格及节点风险一律标注半合成。
8. 在以上检验和软件实现之前，V2 的认证状态应为 **DRAFT / MATHEMATICAL-FORMULATION-AUDITED，非 PASS_V2_EXACT**。

## 3.11 公开资料与相关文献（仅作为数据可行性/研究定位证据）

- Schneider Electric, *EcoStruxure Power Build – Medium Voltage*: 官方工具确认可生成并导出配置与订货 BOM，**没有在该页面提供已审核的分工序制造 BOM**。https://www.se.com/ww/en/work/products/product-launch/ecoreal-mv/
- Schneider Electric, *eDesign User Guide – Bill of Material*: 官方说明可显示配置产品清单、型号、数量与价格，但不等同于上游供应或真实工序加工记录。https://productinfo.se.com/edesign_userguide/edesign_user_guide/EN/DOCA0281EN_eDesign_User_Guide%20%28Except%20France%29_0001012752.xml/%24/BillofMaterialCPT_DD01487762
- Schneider Electric, *Product Availability API V2.2*: 官方提供受权限限制的商品交货日期、缺货及预计交期字段，但不是 T2/T3 或外协工序数据库。https://api-explorer.se.com/en/api/product-availability-v2
- *Inventory-kit modelling and delay-level construction for assembled products with production-transportation collaboration in two-echelon suppliers*, IJPR, published online 2026-09-15, DOI 10.1080/00207543.2026.2732142.
- *Deterministic production synchronization and lot-sizing in multi-echelon supply chains with multistage WIP coupling and synchronized delivery cadence*, CIE 220 (2026), 112256, DOI 10.1016/j.cie.2026.112256.
- *Managing material shortages in project supply chains: Inventories, time buffers, and supplier flexibility*, POM 32(11) (2023), DOI 10.1111/poms.14059.

**引用说明**：本文数学公式是当前研究方案构造，不是对上述论文的公式复制；公开文献仅支持这些业务/算法方向已存在研究，不能据此声称本模型为首次提出。
