"""Independent small LP witness/negative tests for selected V2 physical flows.

NOT a full implementation of the V2 multi-product robust MILP and not global
optimality certification. Checks one BOM with A (stage 1), B (stage 2), one
T3 input and one T2, optional external stage-1 and WIP return.

Run: python v2_micro_flow_check.py
"""
from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np
from scipy.optimize import linprog


@dataclass(frozen=True)
class Toy:
    name: str
    T: int = 3
    deadline: int = 3
    xi: float = 0.0
    theta: float = 0.0
    backup_reserved: float = 1.0
    normal_lead: int = 1
    backup_lead: int = 1
    t2_lead: int = 1
    wip_lead: int = 1
    main_A0: float = 1.0
    main_B0: float = 0.0
    ext_A0: float = 0.0
    internal_p1: tuple[float, ...] = (1.0, 0.0, 0.0)
    ext_p1: tuple[float, ...] = (0.0, 0.0, 0.0)
    internal_p2: tuple[float, ...] = (0.0, 0.0, 1.0)


class LP:
    def __init__(self):
        self.names = []
        self.c = []
        self.ub = []
        self.eq_rows = []
        self.eq_rhs = []
        self.ineq_rows = []
        self.ineq_rhs = []

    def add(self, name: str, cost: float = 0, upper: float | None = None):
        i = len(self.names)
        self.names.append(name)
        self.c.append(cost)
        self.ub.append((0, upper))
        return i

    def eq(self, row, rhs=0):
        self.eq_rows.append(dict(row)); self.eq_rhs.append(rhs)

    def le(self, row, rhs=0):
        self.ineq_rows.append(dict(row)); self.ineq_rhs.append(rhs)

    def solve(self):
        n = len(self.names)
        def dense(rows):
            a = np.zeros((len(rows), n))
            for k, row in enumerate(rows):
                for i, v in row.items():
                    a[k, i] += v
            return a
        r = linprog(self.c, A_eq=dense(self.eq_rows), b_eq=self.eq_rhs,
                    A_ub=dense(self.ineq_rows), b_ub=self.ineq_rhs,
                    bounds=self.ub, method='highs')
        if not r.success:
            raise RuntimeError(f'{r.status}: {r.message}')
        eq_resid = float(np.max(np.abs(dense(self.eq_rows) @ r.x - self.eq_rhs)))
        ub_resid = float(max(0, np.max(dense(self.ineq_rows) @ r.x - self.ineq_rhs)))
        return r, max(eq_resid, ub_resid)


def check(d: Toy):
    p = LP()
    flows = {}
    stores = {}
    flowtypes = ('normal', 'backup', 'produceB', 'sendB', 'stage1main',
                 'stage1out', 'wipSend', 'stage2', 'customerSend')
    storetypes = ('rawT2', 'finishedT2', 'A_main', 'B_main',
                  'A_out', 'WIP_main', 'WIP_out', 'finished_main')
    for t in range(1, d.T + 1):
        for name in flowtypes:
            upper = 0 if name == 'customerSend' and t > d.deadline else None
            flows[name, t] = p.add(f'{name}[{t}]', upper=upper)
        for name in storetypes:
            stores[name, t] = p.add(f'{name}[{t}]')
    sigma = p.add('shortfall', cost=1)
    unmet = p.add('unmet')

    def balance(kind, t, terms, initial=0):
        row = {stores[kind, t]: 1}
        if t > 1:
            row[stores[kind, t-1]] = -1
        for k, v in terms:
            row[k] = row.get(k, 0) + v
        p.eq(row, initial if t == 1 else 0)

    def fl(kind, t):
        return flows[kind, t] if 1 <= t <= d.T else None

    def terms(*x):
        return [(i, c) for (i, c) in x if i is not None]

    for t in range(1, d.T + 1):
        p.le({flows['normal',t]: 1}, 1 - d.xi)
        p.le({flows['backup',t]: 1}, d.xi)
        p.le({flows['produceB',t]: 1}, 1)
        p.le({flows['stage1main',t]: 1}, d.internal_p1[t-1])
        p.le({flows['stage1out',t]: 1}, d.ext_p1[t-1] * (1 - d.theta))
        p.le({flows['stage2',t]: 1}, d.internal_p2[t-1])

        balance('rawT2', t, terms((fl('normal',t-d.normal_lead),-1),
                                  (fl('backup',t-d.backup_lead),-1),
                                  (fl('produceB',t),1)))
        balance('finishedT2', t, terms((fl('produceB',t),-1),
                                       (fl('sendB',t),1)))
        balance('A_main', t, terms((fl('stage1main',t),1)), d.main_A0)
        balance('A_out', t, terms((fl('stage1out',t),1)), d.ext_A0)
        balance('B_main', t, terms((fl('sendB',t-d.t2_lead),-1),
                                    (fl('stage2',t),1)), d.main_B0)
        balance('WIP_out', t, terms((fl('stage1out',t),-1),
                                    (fl('wipSend',t),1)))
        balance('WIP_main', t, terms((fl('stage1main',t),-1),
                                     (fl('wipSend',t-d.wip_lead),-1),
                                     (fl('stage2',t),1)))
        balance('finished_main', t, terms((fl('stage2',t),-1),
                                           (fl('customerSend',t),1)))
    p.le({flows['backup',t]: 1 for t in range(1,d.T+1)}, d.backup_reserved)
    row = {flows['customerSend',t]: 1 for t in range(1,d.deadline+1)}
    row[unmet] = 1
    p.eq(row,1)
    service = {sigma: -1}
    for t in range(1,d.deadline+1):
        service[flows['customerSend',t]] = -1
    p.le(service, -1)
    result, residual = p.solve()
    assert residual < 1e-8, residual
    return {
        'case': d.name,
        'status': 'OPTIMAL',
        'minimum_service_shortfall': round(float(result.fun), 8),
        'max_residual': residual,
        'flow': {name:round(float(result.x[i]),6) for name,i in zip(p.names, range(len(p.names)))
                 if abs(result.x[i]) > 1e-8 and name.startswith(('stage1','stage2','wipSend','customerSend'))}
    }


def main():
    cases = [
        (Toy('normal_internal_partial_assembly', xi=0), 0),
        (Toy('half_disruption_backup_fractional', xi=.5), 0),
        (Toy('full_T3_disruption_with_backup', xi=1), 0),
        (Toy('full_T3_disruption_without_backup', xi=1, backup_reserved=0), 1),
        (Toy('backup_arrives_too_late', xi=1, backup_lead=2), 1),
        (Toy('external_WIP_returns_in_time', T=3, deadline=2, xi=1, backup_reserved=0,
             main_A0=0, main_B0=1, ext_A0=1, internal_p1=(0,0,0),
             ext_p1=(1,0,0), internal_p2=(0,1,0), wip_lead=1), 0),
        (Toy('external_partner_down', T=3, deadline=2, xi=1, backup_reserved=0,
             main_A0=0, main_B0=1, ext_A0=1, internal_p1=(0,0,0),
             ext_p1=(1,0,0), internal_p2=(0,1,0), theta=1, wip_lead=1), 1),
        (Toy('external_WIP_returns_too_late', T=3, deadline=2, xi=1, backup_reserved=0,
             main_A0=0, main_B0=1, ext_A0=1, internal_p1=(0,0,0),
             ext_p1=(1,0,0), internal_p2=(0,1,0), theta=0, wip_lead=2), 1),
    ]
    outputs = []
    for item, expected in cases:
        r = check(item)
        assert abs(r['minimum_service_shortfall']-expected) < 1e-8, (item.name,r)
        outputs.append(r)
        print(f"{item.name}: min service shortfall={r['minimum_service_shortfall']}; residual={r['max_residual']:.2g}")
    here = Path(__file__).resolve().parent
    (here/'v2_micro_flow_evidence.json').write_text(json.dumps(outputs,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{len(outputs)} / {len(cases)} tiny scenario checks passed')

if __name__ == '__main__':
    main()
